<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Nova tarefa</name>
   <tag></tag>
   <elementGuidId>d23b20bd-4e75-4bc2-a1f9-e228bca2b3db</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Nova tarefa')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Nova tarefa&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4eec577a-b89f-4749-ad8c-b9a247d84c4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/create</value>
      <webElementGuid>00c2062a-5f17-4d83-a1c6-b92aff2b18e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary</value>
      <webElementGuid>6beb7ea4-3629-4355-bbb3-66d0f30376d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Nova tarefa</value>
      <webElementGuid>05a47c1b-2564-4b21-8b61-e78a0ca6e0dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;container&quot;]/a[@class=&quot;btn btn-primary&quot;]</value>
      <webElementGuid>8bc584d6-e62c-48b5-9181-e385d67abb25</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Nova tarefa')]</value>
      <webElementGuid>cfb82901-dc44-4c38-8324-547ffbaa13d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nenhuma tarefa encontrada.'])[1]/following::a[1]</value>
      <webElementGuid>61ec976d-f2af-47ae-943f-7372eade6358</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lista de tarefas'])[1]/following::a[1]</value>
      <webElementGuid>a5931f96-419b-4679-9035-d28b42d0ada1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Nova tarefa']/parent::*</value>
      <webElementGuid>1672f617-c5cf-414d-9459-ab8e6901e180</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/create')]</value>
      <webElementGuid>ac245a90-cf0d-430c-8e28-6dc0024fb761</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/a</value>
      <webElementGuid>7c45f1fc-9f04-4952-9724-84935fcb9444</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/create' and (text() = 'Nova tarefa' or . = 'Nova tarefa')]</value>
      <webElementGuid>1c6ca61c-385a-4a2b-8ba7-b6cbbdb53b50</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
